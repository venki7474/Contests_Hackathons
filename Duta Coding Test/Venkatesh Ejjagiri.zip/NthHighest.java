import java.util.*;
public class NthHighest {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String inp_str = scan.nextLine();
		int n = Integer.parseInt(inp_str.substring(inp_str.length()-1));
		String inp_parsed = inp_str.substring(1, inp_str.length()-4);
		// System.out.println(n +" "+ inp_parsed);
		String[] inp_arr_str = inp_parsed.split(",");
		ArrayList<String> list = new ArrayList<String>(Arrays.asList(inp_arr_str));
		Collections.sort(list);
		if (n <= list.size()) {
			System.out.println(list.get(list.size() - n ));
		} else {
			System.out.println("Entered number is out of range");
		}
	}
}

            import java.util.*;
            class CardCatalog
            {
              Card[] theTitle;
              Card[] theAuthor;
              Card[] theSubject;
              static int index = 0;
              int i;
              CardCatalog()
              {
        
                theTitle = new Card[10];
                theAuthor = new Card[10];
                theSubject = new Card[10];
            }
        
            public void addACard(Card crd)
            {
                 
                     theTitle[i]=crd;
                     theAuthor[i]=crd;
                     theSubject[i]=crd;
                     i++;
                    /*}
                    else
                    {
                        for(int a=0;a<=i;a++)
                        {
                            if(crd.title.compareToIgnoreCase(theTitle[a].title)<0)
                            {
                                for(int j=i;j>a;j--)
                                {
                                    theTitle[j]=theTitle[j-1];
                                }
                                theTitle[a]=crd;
                                break;
                            }
                            else if(a+1==i)
                            {
                                    theTitle[i]=crd;
                                }   
                            }
                    for(int a=0;a<=i;a++)
                    {
                        if(crd.author.compareToIgnoreCase(theAuthor[a].author)<0)
                        {
                            for(int j=i;j>a;j--)
                            {  
                                theAuthor[j]=theAuthor[j-1];
                            }        
                            theAuthor[a]=crd;
                            break;
                        }
                        else if(a+1==i)
                        {
                            theAuthor[i]=crd;
                        }
                    }
                    for(int a=0;a<=i;a++)
                    {
                        if(crd.subject.compareToIgnoreCase(theSubject[a].subject)<0)
                        {
                            for(int j=i;j>a;j--)
                            {
                                theSubject[j]=theSubject[j-1];
                            }
                            theSubject[a]=crd;
                            break;
                        }
                        else if(a+1==i)
                        {
                            theSubject[i]=crd;
                        }
                    }
                    i++;
       }*/
    }
        
                public void printAll()
                {
                    for(int j=0;j<5;j++)
                    {
                       int k;
                       k=j;
                       k++;
                       System.out.println(k+"."+"Title:" +theTitle[j].title +" Author:"+theTitle[j].author +"Subject:"+theTitle[j].subject);
                       System.out.println("==========================================================");
                   }
               }
        
               public void printTheCatalog()
               {
                System.out.println("Enter 1 to get by Title.");
                System.out.println("Enter 2 to get by Author.");
                System.out.println("Enter 3 to get by Subject.");
                Scanner sc = new Scanner(System.in);
                int x = sc.nextInt();
                switch(x)
                {
        
                 case 1:for(int j=0;j<index;j++)
                        {
                            int k;
                            k=j;
                            k++;
                            System.out.println(k+"."+"Title:" +theTitle[j].title +" Author:"+theTitle[j].author+" Subject:"+theTitle[j].subject);
                            System.out.println("==========================================================");
        
                        }
                            break;
        
                 case 2:for(int j=0;j<index;j++)
                        {
                            int k;
                            k=j;
                            k++;
                            System.out.println(k+"."+"Author:" +theAuthor[j].author +" Title:"+theAuthor[j].title+" Subject:"+theAuthor[j].subject);
                            System.out.println("==========================================================");
        
                        }
                            break;
        
                case 3:for(int j=0;j<index;j++)
                        {
                            int k;
                            k=j;
                            k++;
                            System.out.println(k+"."+"Subject:" +theSubject[j].subject +"Title:"+theSubject[j].title+" Author:"+theSubject[j].author);
                            System.out.println("==========================================================");
        
                        }
                            break;
                default: System.out.println("invalid option");
        
            }
        
        
        }
        
        public void getATitle(String s_Title)
        {
            for(int j=0;j<index;j++)
            {
                if(theTitle[j].title.equalsIgnoreCase(s_Title))
                {
                    printCard(theTitle[j]);
                    break;
                }
            } 
                    
        }
        
        public void printCard(Card crd1)
        {
            System.out.println("Title:" +crd1.title);
            System.out.println("Author:" +crd1.author);
            System.out.println("Subject:" +crd1.subject);
        }
        
        public void getAnAuthor(String s_Author)
        {
            for(int j=0;j<index;j++)
            {
                if(theAuthor[j].author.equalsIgnoreCase(s_Author))
                {  
                  printCard(theAuthor[j]);
                }
            }
        }
        
        public void getSubject(String s_Subject)
        {
            for(int j=0;j<index;j++)
            {
                if(theSubject[j].subject.equalsIgnoreCase(s_Subject))
                {
                    printCard(theSubject[j]);
                    
                }
            }
        }
        
        
        
        public void removeATitle(Card c)
        {
            for(int j=0;j<index;j++)
            {
                if(c.title.compareTo(theTitle[j].title)==0)
                {
                    for(int k=j;k<index-1;k++)
                    {
                        theTitle[k]=theTitle[k+1];
                    }
                }
        
                if(c.title.compareTo(theAuthor[j].title)==0)
                {
                    for(int k=j;k<index-1;k++)
                    {
                        theAuthor[k]=theAuthor[k+1];
                    }
                }
        
                if(c.title.compareTo(theSubject[j].title)==0)
                {
                    for(int k=j;k<index-1;k++)
                    {
                        theSubject[k]=theSubject[k+1];
                    }
                }
            }
            index--;
            for(int l=0;l<index;l++)
            {
                int m;
                m=l;
                m++;
                System.out.println("enterd title book is removed and the remaining books are:");
                System.out.println(m+"."+"Title:" +theSubject[l].title +"\nAuthor:"+theSubject[l].author+"\nSubject:"+theSubject[l].subject);
                System.out.println("==========================================================");
            }
        }
        
        }
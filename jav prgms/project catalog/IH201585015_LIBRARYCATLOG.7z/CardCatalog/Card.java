  class Card
  {
      
      public String title;
      public String subject;
      public String author;

      public Card(String title,String author,String subject )
      {
        this.author=author;
        this.title=title;
        this.subject=subject;
        //System.out.println(title);
        //System.out.println(author);
        //System.out.println(subject);
       
      }
  }


    import java.util.*;
    public class Menu
    {
             static int y;
        
     public static void main(String[] args)
        {
         String s_Title;
         String s_Author;
         String s_Subject;
         String rmv_Title;

            
           Card[] card = new Card[5];

             card[0] = new Card("Let us c","yashwanth","c");
           
             card[1] = new Card("Let us Java","Allen B.Downey","Java");
            
             card[2] = new Card("The complete reference for Java","Herbert Schildt","Java");
             
             card[3] = new Card("Let us c","Herbert Schildt","c");
                 
                 card[4] = new Card("Algorithms","Thomas","Data Structures");
            CardCatalog cc = new CardCatalog();
           // Card cd;
           for(int i=0;i<5;i++)
           {
            cc.addACard(card[i]);
           }
           
            do
            {
            System.out.println("enter 1 to get by the title:");
            System.out.println("enter 2 to get by the Author:");
            System.out.println("enter 3 to get by the Subject:");
            System.out.println("enter 4 to remove the title:");
            System.out.println("enter 5 to print the catalog:");
            Scanner sc = new Scanner(System.in);
            int x = sc.nextInt();
            switch(x)
            {
            case 1: System.out.println("enter the title to be searchd");
                    Scanner s = new Scanner(System.in);
                    s_Title=s.nextLine();
                    cc.getATitle(s_Title);
                    
                   break;
            
            case 2: System.out.println("enter the author to be searchd");
                    Scanner s1 = new Scanner(System.in);
                    s_Author=s1.nextLine();
                    cc.getAnAuthor(s_Author);
                    break;
                    
            case 3: System.out.println("enter the subject to be searchd");
                    Scanner s2 = new Scanner(System.in);
                    s_Subject=s2.nextLine();
                    cc.getSubject(s_Subject);
                    break;
            
            case 4: cc.printAll();
                    System.out.println("enter the book number to be deleted");
                    Scanner sc1 = new Scanner(System.in);
                    int n = sc1.nextInt();
                    if(n<=5)
                    {
                    cc.removeATitle(card[n-1]);
                    }
                    else
                    {
                        System.out.println("enter the valid book number");
                    }
                    break;
                    
            case 5: cc.printTheCatalog();
                    break;
                    
            default : System.out.println("enter the valid number");
            
            }
            System.out.println("Enter 0 to exit and 1 to continue:");
            Scanner sc1 = new Scanner(System.in);
            y = sc1.nextInt();
            
            }while(y!=0 && y==1);
            


        }

    }
